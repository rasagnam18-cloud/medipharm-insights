# Medipharm Insights — Free Website

## Open locally
Double-click `index.html` or open it in a browser.

## Publish for free
1. Create a GitHub account.
2. Create a new public repository, e.g. `medipharm-insights`.
3. Upload `index.html`.
4. In Settings → Pages, choose Deploy from branch → main → root.
5. GitHub will provide a free `https://YOUR-USERNAME.github.io/medipharm-insights/` address.

## Before launch
- Replace the demo email address with your real business email.
- Replace sample dashboard data with verified/licensed data.
- Add your final company details and privacy/terms pages.
- If you use a form provider, update the form action instead of the mailto function.
